SuperDoctor III and SuperDoctor III Client README file
Copyright (c) 1993-2012 Supermicro Computer Inc.
*******************************************************************************
*  Product: Supermicro(R) SuperDoctor III and SuperDoctor III Client
*  Release: Production Version
*  Version: SuperDoctor III 1.59.452
*           SuperDoctor III Client 1.59
*  Date: May 29, 2014
*******************************************************************************


*******************************************************************************
*  CONTENTS OF THIS DOCUMENT
*******************************************************************************
This document contains the following sections:

1. Introduction
2. System Requirements
3. Third-Party Program and Software Components
4. Installation Instructions
5. Uninstall Instructions
6. Troubleshooting and FAQs
7. Legal/Disclaimers


*******************************************************************************
* 1.  INTRODUCTION
*******************************************************************************
SuperDoctor III (or SDIII for short), a web based software, keeps the key
functions included in SuperDoctor II and extends them with new features, such
as detailed Windows platform system and performance information, hardware health
information, remote console redirection, power cycle management,user accounts
and groups management and reports, all to enhance the capabilities of remote
management.
SuperDoctor III Client (or SDIII Client for short) is a standalone application
and a new revision of SuperDoctor II. It contains only a subset of the func-
tions of SuperDoctor III and must be running on the local system. Some new
features that have been added:
1) Changeable high and low threshold limits of system health monitoring.
2) E-Mail alerts thatsupport  SMTP authentication.
3) History log of system health monitor readings for future reference.
4) Event Log


*******************************************************************************
* 2.  SYSTEM REQUIREMENTS
*******************************************************************************
1. This software is designed to run under the following operating systems:

	Windows NT 4.0 with Service Pack 4.0 or later
	Windows 2000
	Windows XP
	Windows Server 2003

2. It is recommended that a minimum of 14MB of hard disk space be available on
   the system in order to install this software.


*******************************************************************************
* 3.  THIRD-PARTY PROGRAM AND SOFTWARE COMPONENTS
*******************************************************************************
This software utilizes the following programs and software components from
the following third-parties:

1. Xitami web server (from http://www.imatix.com).
2. TridiaVNC (from http://www.tridiavnc.com).
3. SndMail 2.1 (from http://xmailserver.org/davide.html).
4. Windows Management Instrumentation(WMI) CORE 1.5 (for Windows NT 4.0)
   (from http://www.microsoft.com).


*******************************************************************************
* 4.  INSTALLATION INSTRUCTIONS
*******************************************************************************
Preparation
In order to support SNMP, SNMP service must be installed before installing this
software. If SNMP is not a request, you may skip this preparation.  Please
follow these steps to install SNMP service:

For Windows 2000/Windows XP/Windows 2003:
1.	Open the Control Panel
2.	Open Add/Remove Programs
3.	Open Add/Remove Windows Components
4.	Open Management and Monitoring Tools in the Components List
5.	Check Simple Network Management Protocol
6.	Click "Next" to begin the installation

For Windows NT 4.0:
1.	Right Click on Network Neighborhood
2.	Open Properties
3.	Click on Services
4.	Choose Add
5.	Choose "SNMP service" from the list
6.	You'll be asked to insert the NT 4.0 CD into your CD-ROM drive
7.	Reboot the system

Please follow the instructions step-by-step as shown below to complete the
installation of the SuperDoctor III and SuperDoctor III Client:

1. Double click Setup.exe to start the installation procedure and the "Welcome
   to the InstallShield Wizard for SuperDoctor III" window will show up. Click
   the "Next >" button to continue.
2. The "License Agreement of SuperDoctor III" window is displayed. Click the
   "Yes" button to accept all the terms of the License Agreement after reading it.
3. Another "License Agreement of SndMail 2.1" window appears. SuperDoctor III
   utilizes SndMail 2.1 to send E-Mail alerts. Click the "Yes" button to accept
   all the terms of the License Agreement after reading it.
4. The "Setup Type" window allows you to select to install "SuperDcotor III
   and Client" or "SuperDoctor III Client only". Read the descriptions and
   select the setup type depending on your needs. To install "SuperDoctor III
   Client only", please select "SuperDoctor III Client only" and click the
   "Next >" button and then jump ahead to Step 10. For installing "SuperDoctor
   III and Client", please proceed to the next step.
5. SuperDoctor III uses the Xitami web server as adefault web server. Please
   click the "Yes" button to accept all the terms of the License Agreement after
   reading it.
6. The "License Agreement of TridiaVNC" window is displayed. SuperDoctor III
   utilizes TridiaVNC to implement the remote console redirection capability.
   Please click the "Yes" button to accept all the terms of the License Agreement
   after reading it.
7. In the "Information" window, the installation program shows the programs or
   software components that will be installed together within SuperDoctor III.
   Please do not forget to change the default passwords for the Xitami web server
   and TridiaVNC after installation and system reboot. Click the "Next >" button
   to continue.
8. To install SuperDoctor III onto Windows NT 4.0, you will first need to setup
   the WMI Core Components. In the "WMI Core Components" window, click the "Next>
   " button to continue.
9. Please key in the TCP port for the Xitami web server. The default port number
   is 80. You can choose any available port number between 1025 and 65535 if an-
   other web server using port 80 is currently running on the system. Click the
   "Next >" button to continue.
10.In the "Choose Destination Location" window, click the "Next >" button to ac-
   cept the default Destination Folder (C:\Program Files\SDIII). Alternatively,
   click the "Browse�K" button to select another Destination Folder.
11.Next, the install program will determine if SNMP service is installed on your
   system. If the system does not have SNMP service installed, the "SNMP Service
   is not found" window will appear. If you want to install SNMP service, check
   "Yes, I want to exit the install program and install SNMP service first. (re-
   commended)" and click the "Next >" button to go to the next step. If you want
   to install SuperDoctor III without SNMP service, please check "No, install
   SuperDoctor III without SNMP service" then clicking the "Next >" button and
   proceed on to Step15. Otherwise, if the SNMP service is already installed,
   please proceed to Step 14.
12.Instructions for installing the SNMP service in Windows NT/2000/XP will be
   displayed in the "Information" window for your reference. Click the "OK"
   button to continue.
13.Click the "OK" button to terminate the installation program. After the SNMP
   service is installed, please run Setup.exe again.
14.If the SNMP service is installed, you will be asked to install SuperDoctor
   SNMP agent. You can check "Yes, install SuperDoctor SNMP agent.(recommended)
   " and click "Next >" to install it. If you don't want to do so, please check
   "No, do not install SuperDoctor SNMP agent." and click "Next >".
15.The installation program will begin copying files.
16.After the installation program is completed, you will be asked to restart the
   system. You have to restart the system before you can use SuperDoctor III.
   Check "Yes, I want to restart my computer now" or "No, I will restart my com-
   puter later" and click the "Finish" button to exit the installation program.


*******************************************************************************
* 5.  UNINSTALL INSTRUCTIONS
*******************************************************************************
Please follow the instructions shown below to uninstall the SuperDoctor III
and SuperDoctor III Client:

1. In the Control Panel, double click "Add or Remove Programs". Select "SuperDoctor
   III" and click the "Change/Remove" button to start to uninstall SuperDoctor III. 
   Click the "Yes" button in the "Are you sure you want to uninstall SuperDoctor III 
   Client (and SuperDoctor III)?" pop-up dialog. Some SuperDoctor III related services
   will be stopped.
2. In the "Shared File Detected" window, click the "Yes" button to delete shared
   files installed in SuperDoctor III. Note: there may be more than one shared
   file. Please do not click the "Cancel" button.
3. Some running files related to SuperDoctor III might be locked. In the "Locked
   File Detected" window, click the "Reboot" button to delete any locked files
   after system reboot (recommended.) Or click the "Ignore" button to keep the
   locked files. Note: there might be more than one locked file.
4. After uninstalling, please click the "Finish" button to exit the uninstall
   program. Note: some locked files won't be deleted until the system has been
   restarted.


*******************************************************************************
* 6.  TROUBLESHOOTING AND FAQs
*******************************************************************************
Question: During the installation procedure, the installation program pops up a
	  "SuperDoctor III can only be installed on Super Micro products" dialog.
Answer:   SuperDoctor III can only be installed on Supermicro products. Why?
          Please visit http://www.supermicro.com for information about Supermicro
          products. SDIII shows much information that highly depends on hardware
          design. Thus hardware the configuration differs from board to board.

Question: During the installation procedure, a dialog window pops up that reads 
          "SuperDoctor III can only be installed on Supermicro products".  
          What does this mean?
Answer:   SuperDoctor III can only be installed on Supermicro products. Why? 
          Please visit http://www.supermicro.com/ for information about Supermicro
          products. SuperDoctor III shows much information that highly depends
          on hardware design. Thus the hardware configuration will differ from 
          board to board. 

Question: During the installation procedure a dialog window pops up that reads 
          "We cannot find your computer model in our current definition, probably 
          your computer is new to this version of SuperDoctor III. Do you have 
          a new definition?". What does this mean? 
Answer:   Your system might contain a new Supermicro server or motherboard whose 
          configuration is not included in the latest version of SuperDoctor 
          III you are installing. Please visit ftp://ftp.supermicro.com/utility/
          SuperDoctorIII/AllSuperD.ini to download the latest definition and 
          provide it when the installation program asks for the new definition 
          file. 

Question: What is the default password for the Xitami Web Server? 
Answer:	  User ID = ADMIN, Password = ADMIN

Question: What is the default password for the TridiaVNC (Console Redirection) 
          in Remote Control? 
Answer:   Password = abcde

Question: Where can I get more information on the Xitami Web Server? 
Answer:   Please visit http://Server_IP_Address/xitami/
          (or http://Server_IP_address:Port/xitami/ if different port is used).

Question: How do I manage the Xitami Web Server? 
Answer: 	
          1.Visit http://Server_IP_Address/admin/
            (or http://Server_IP_Address:Port/admin/ if different port is used)
          2.Enter User name and Password.
          3.Manage the Xitami Web Server as you wish.

Question: How can I change the ID and password of the Xitami Web Server? 
Answer:   Find the Xitami Basic Authentication file and then modify it. 
          Before modifying the file, please read Xitami Help and xitami.aut for 
          reference. 
          1.Visit http://Server_IP_Address/admin/ 
            (or http://Server_IP_Address:Port/admin/ if different port is used).
          2.Enter User name and password.
          3.Choose "Configuration".
          4.Choose "Security".
          5.The Xitami Basic Authentication filename is in the password File 
            field. The default is defaults.aut
          6.Modify that file as needed. 

Question: How can I change the TridiaVNC Server's password? 
Answer: 
          1.Run "winvnc.exe -defaultsettings" (in .\system32\) from Command Prompt. 
          2.Choose a new password in the password field of the popping out dialog
            "WinVNC: Default local System Properties".
          3.Click on OK button to finish the process.

Question: How can I change the password in SuperDoctor III?
Answer:
          1.Visit http://Server_IP_Address/
            (or http://Server_IP_Address:Port/ if different port is used).
          2.Enter User ID and password.
          3.Click "Administration".
          4.Set the new password for the user as you wish.  

Question: How can I change the IP port number for SuperDoctor III?
Answer:   Just change the IP port number for the Xitami Web Server.
          1.Visit http://Server_IP_Address/admin/
            (or http://Server_IP_Address:Port/admin/ if different port is used).
          2.Enter User name and password.
          3.Choose "Configuration".
          4.Choose "Server".
          5.Choose a new setting in the "IP port base" field. Add 80 to this to 
            calculate the actual port used for the HTTP service. 
          6.Before exiting, click "Save" to save your changes.
          7.If at the local site, skip to the next step. If at a remote site, 
            visit http://Server_IP_Address/ 
            (or http://Server_IP_Address:Port/admin/ if different port is used) 
            and go to "Remote Control" => "Open Console".
          8.Go to Start => All Programs => Administrative Tools => Services. 
          9.Restart "Xitami Web Server" Service.

Question: Why are some of the components not detected by SuperDoctor III? 
nswer:	  SuperDoctor III uses WMI (Windows Management Instrumentation) to 
          monitor your system, and only displays whatever components/software 
          the WMI detects in your system. In other words, SuperDoctor III can 
          only reflect and report to you what WMI sees from your system. It does
          not interfere with the operation of WMI. In addition, the configuration 
          and the installation of software/hardware will greatly influence the 
          way how WMI collects data from the system and this will result in 
          variations of the components/software detected by the WMI. To better 
          understand how each hardware or software component functions in your 
          system, please contact its manufacturer or vendor. For details on WMI, 
          please refer to the question "What is WMI?" listed below. 

Question: What is WMI? 
Answer:	  WMI, or Windows Management Instrumentation, is a component of Microsoft 
          Windows Operating System. It is used to provide information on system 
          management so that IT professionals can gain better control over 
          computer systems in an enterprise environment. 
          For more information, please visit Microsoft's web site at 
          http://msdn.microsoft.com/library/en-us/wmisdk/wmi/wmi_start_page.asp 

Question: What does each item in the "System Information" field mean? 
Answer:   The purpose and function of SuperDoctor III is to accurately reflect 
          and display the information provided by WMI. It is intended to interpret 
          or intercept what WMI detects from the system. 
          To better understand the meaning of data detected by WMI, please go to 
          the WMI class and reference page on Microsoft's web site at 
          http://msdn.microsoft.com/library/en-us/wmisdk/wmi/wmi_classes.asp 

Question: What does each item in the "Performance" field mean? 
Answer:	  SuperDoctor III displays information on System Performance in order 
          to provide the user with a tool for troubleshooting. It does not offer 
          interpretations or explanations on the data being gathered from 
          operating system. In addition to displaying data on System Performance, 
          SuperDoctor III also allows you to access the same information from 
          a remote location via the utilities provided by the Operating System. 
          For more details regarding the items listed in the "Performance" field, 
          please visit Microsoft's web site at 
          http://msdn.microsoft.com/library/en-us/perfmon/base/performance_data.asp

*******************************************************************************
* 7.  LEGAL/DISCLAIMERS
*******************************************************************************
Supermicro makes no claims of usability, efficacy or warranty.
Information in this document is provided in connection with Supermicro(R)
products. No license, either expressed or implied, by estoppel or otherwise, to
any intellectual property rights is granted by this document. Supermicro assumes
no liability whatsoever, and Supermicro disclaims any expressed or implied warranty
relating to the sale and/or use of Supermicro(R) products, including liability or
warranties relating to fitness for a particular purpose, merchantability or
infringement of any patent, copyright or other intellectual property right.
Supermicro(R) products are not intended for use in medical, life saving, or
life-sustaining applications.
Supermicro Computer Inc. disclaims all warranties and liabilities for the use
of this document and the information contained herein, and assumes no responsi-
bility for any errors which may appear in this document, nor does Supermicro
make a commitment to update the information contained herein. Supermicro
reserves the right to make changes to this document at any time, without notice.

* Supermicro is a trademark or registered trademark of Supermicro Computer Inc.
  or its subsidiaries in the United States and other countries.
* Other brands and names are the properties of their respective owners.

Copyright (c) 1993-2012 Supermicro Computer Inc.

